package io.dazzleduck.sql.logger;

import io.dazzleduck.sql.commons.types.JavaRow;
import io.dazzleduck.sql.commons.types.VectorSchemaRootWriter;
import io.dazzleduck.sql.commons.types.VectorWriter;
import io.dazzleduck.sql.commons.types.ElementWriteFunction;
import org.apache.arrow.memory.RootAllocator;
import org.apache.arrow.vector.VarCharVector;
import org.apache.arrow.vector.VectorSchemaRoot;
import org.apache.arrow.vector.types.pojo.*;
import org.apache.arrow.vector.ipc.ArrowStreamWriter;
import org.slf4j.helpers.LegacyAbstractLogger;
import org.slf4j.Marker;
import org.slf4j.event.Level;
import org.slf4j.event.LoggingEvent;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.Serial;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * SLF4J logger that prints to console and asynchronously sends Arrow batches to Flight server.
 */
public class ArrowSimpleLogger extends LegacyAbstractLogger {

    @Serial
    private static final long serialVersionUID = 1L;
    private static final RootAllocator allocator = new RootAllocator();
    private static final Schema schema = new Schema(List.of(
            new Field("timestamp", FieldType.nullable(new ArrowType.Utf8()), null),
            new Field("level", FieldType.nullable(new ArrowType.Utf8()), null),
            new Field("logger", FieldType.nullable(new ArrowType.Utf8()), null),
            new Field("thread", FieldType.nullable(new ArrowType.Utf8()), null),
            new Field("message", FieldType.nullable(new ArrowType.Utf8()), null)
    ));

    private final String name;
    private final AsyncArrowFlightSender flightSender;

    // Constructor with explicit sender
    public ArrowSimpleLogger(String name, AsyncArrowFlightSender flightSender) {
        this.name = name;
        this.flightSender = flightSender;
    }

    // Default constructor using singleton sender
    public ArrowSimpleLogger(String name) {
        this(name, AsyncArrowFlightSender.getDefault());
    }

    @Override
    protected String getFullyQualifiedCallerName() {
        return this.name;
    }

    @Override
    protected void handleNormalizedLoggingCall(Level level, Marker marker, String messagePattern, Object[] arguments, Throwable throwable) {
        String formatted = format(messagePattern, arguments);
        writeConsole(level, formatted, throwable);
        writeArrowAsync(level, formatted);
    }

    /** Console output */
    private void writeConsole(Level level, String message, Throwable t) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
        String thread = Thread.currentThread().getName();
        PrintStream out = System.out;
        out.printf("%s [%s] %s - %s%n", timestamp, level, name, message);
        if (t != null) t.printStackTrace(out);
    }

    /** Format message */
    private String format(String messagePattern, Object[] args) {
        if (args == null || args.length == 0) return messagePattern;
        String msg = messagePattern;
        for (Object arg : args) {
            msg = msg.replaceFirst("\\{}", arg == null ? "null" : arg.toString());
        }
        return msg;
    }

    /** Convert log into Arrow bytes and enqueue for async Flight send */
    private void writeArrowAsync(Level level, String message) {
        try {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
            String thread = Thread.currentThread().getName();
            JavaRow logRow = new JavaRow(new Object[]{
                    timestamp, level.toString(), name, thread, message
            });

            var varcharWriter = new VectorWriter.VarCharVectorWriter();
            var vectorSchemaRootWriter = new VectorSchemaRootWriter(
                    schema,
                    varcharWriter, varcharWriter, varcharWriter, varcharWriter, varcharWriter
            );

            // setSafe() calls with vector writer logic
            try (VectorSchemaRoot root = VectorSchemaRoot.create(schema, allocator)) {
                vectorSchemaRootWriter.writeToVector(new JavaRow[]{logRow}, root);

                ByteArrayOutputStream outBuf = new ByteArrayOutputStream();
                try (ArrowStreamWriter writer = new ArrowStreamWriter(root, null, outBuf)) {
                    writer.start();
                    writer.writeBatch();
                    writer.end();
                }

                flightSender.enqueue(outBuf.toByteArray());
            }

        } catch (Exception e) {
            System.err.println("[ArrowSimpleLogger] Failed to enqueue log: " + e.getMessage());
        }
    }


    public void log(LoggingEvent event) {
        Level level = event.getLevel();
        if (!isLevelEnabled(level.toInt())) return;

        String message = event.getMessage();
        writeArrowAsync(level, message);
    }

    @Override public boolean isTraceEnabled() { return isLevelEnabled(0); }
    @Override public boolean isDebugEnabled() { return isLevelEnabled(10); }
    @Override public boolean isInfoEnabled()  { return isLevelEnabled(20); }
    @Override public boolean isWarnEnabled()  { return isLevelEnabled(30); }
    @Override public boolean isErrorEnabled() { return isLevelEnabled(40); }

    private boolean isLevelEnabled(int levelInt) {
        // INFO by default
        int currentLogLevel = 20;
        return levelInt >= currentLogLevel;
    }
}
