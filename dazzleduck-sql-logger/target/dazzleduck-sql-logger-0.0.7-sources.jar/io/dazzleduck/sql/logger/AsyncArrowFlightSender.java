package io.dazzleduck.sql.logger;

import org.apache.arrow.flight.*;
import org.apache.arrow.memory.RootAllocator;
import org.apache.arrow.vector.VectorSchemaRoot;
import org.apache.arrow.vector.dictionary.DictionaryProvider;
import org.apache.arrow.vector.ipc.ArrowStreamReader;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * Async sender: enqueue Arrow stream bytes; background worker batches them
 * and sends via Flight doPut every flushInterval or when batchCount reached.
 */
public class AsyncArrowFlightSender implements Closeable {
    private static final int DEFAULT_QUEUE_CAPACITY = 10000;
    private static final int DEFAULT_BATCH_COUNT = 50;
    private static final Duration DEFAULT_FLUSH_INTERVAL = Duration.ofSeconds(2);

    private final BlockingQueue<byte[]> queue;
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "arrow-flight-sender");
        t.setDaemon(true);
        return t;
    });
    private final FlightClient client;
    private final RootAllocator allocator = new RootAllocator();

    private final int batchCount;
    private volatile boolean running = true;

    // default singleton
    private static final AsyncArrowFlightSender DEFAULT =
            new AsyncArrowFlightSender("localhost", 32010, DEFAULT_QUEUE_CAPACITY, DEFAULT_BATCH_COUNT, DEFAULT_FLUSH_INTERVAL);

    public static AsyncArrowFlightSender getDefault() { return DEFAULT; }

    public AsyncArrowFlightSender(String host, int port, int queueCapacity, int batchCount, Duration flushInterval) {
        this.queue = new ArrayBlockingQueue<>(queueCapacity);
        this.batchCount = batchCount;
        Location loc = Location.forGrpcInsecure(host, port);
        this.client = FlightClient.builder(allocator, loc).build();

        // schedule periodic flush
        scheduler.scheduleAtFixedRate(this::flushSafely, flushInterval.toMillis(), flushInterval.toMillis(), TimeUnit.MILLISECONDS);
        scheduler.execute(this::drainLoop);
    }

    public AsyncArrowFlightSender(String host, int port) {
        this(host, port, DEFAULT_QUEUE_CAPACITY, DEFAULT_BATCH_COUNT, DEFAULT_FLUSH_INTERVAL);
    }

    public boolean enqueue(byte[] arrowStreamBytes) {
        if (!running) return false;
        return queue.offer(arrowStreamBytes);
    }

    private void drainLoop() {
        try {
            while (running) {
                List<byte[]> batch = new ArrayList<>(batchCount);
                byte[] first = queue.poll(1, TimeUnit.SECONDS);
                if (first != null) batch.add(first);
                queue.drainTo(batch, batchCount - 1);
                if (!batch.isEmpty()) sendBatch(batch);
            }
        } catch (InterruptedException ignored) {}
    }

    private void flushSafely() {
        try {
            List<byte[]> drained = new ArrayList<>();
            queue.drainTo(drained, batchCount);
            if (!drained.isEmpty()) sendBatch(drained);
        } catch (Exception e) {
            System.err.println("[AsyncArrowFlightSender] periodic flush failed: " + e.getMessage());
        }
    }

    private void sendBatch(List<byte[]> batch) {
        if (batch.isEmpty()) return;

        try {
            for (byte[] bytes : batch) {
                try (ByteArrayInputStream in = new ByteArrayInputStream(bytes);
                     ArrowStreamReader reader = new ArrowStreamReader(in, allocator)) {

                    VectorSchemaRoot root = reader.getVectorSchemaRoot();
                    FlightDescriptor descriptor = FlightDescriptor.path("logs");

                   // AsyncPutListener will handle the server ack
                    AsyncPutListener listener = new AsyncPutListener();
                    // Start the put
                    FlightClient.ClientStreamListener stream = client.startPut(descriptor, listener, (CallOption) root);
                    // Send batches
                    while (reader.loadNextBatch()) {
                        stream.putNext(); // sends current batch
                    }
                       // Complete the stream and wait for ack
                    stream.completed();
                    listener.getResult();

                }
            }
        } catch (Exception e) {
            System.err.println("[AsyncArrowFlightSender] sendBatch failed: " + e.getMessage());
        }
    }


    @Override
    public void close() {
        running = false;
        scheduler.shutdownNow();
        try { client.close(); } catch (Exception ignored) {}
        allocator.close();
    }
}
